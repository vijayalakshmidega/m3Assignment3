import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { M2Module } from './m2/m2.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    M2Module
  ]
})
export class M1Module { }
