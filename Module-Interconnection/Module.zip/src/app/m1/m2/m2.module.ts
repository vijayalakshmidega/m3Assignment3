import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Comp12Component } from 'src/app/m2/comp12/comp12.component';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  exports:[
    Comp12Component
  ]
})
export class M2Module { }
